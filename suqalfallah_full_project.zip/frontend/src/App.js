import React, { useEffect, useState } from "react";
import API from "./api";

function App() {
  const [view, setView] = useState("home");
  const [user, setUser] = useState(null);
  const [stores, setStores] = useState([]);
  const [favorites, setFavorites] = useState([]);
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    fetchStores();
    const token = localStorage.getItem("token");
    if (token) fetchMe();
  }, []);

  const fetchStores = async () => {
    try {
      const res = await API.get("/stores");
      setStores(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchMe = async () => {
    try {
      const res = await API.get("/users/me");
      setUser(res.data.user);
      setFavorites(res.data.stores || []);
      setNotifications(res.data.notifications || []);
    } catch (err) {
      console.error(err);
      localStorage.removeItem("token");
    }
  };

  const handleRegister = async (form) => {
    try {
      const res = await API.post("/auth/register", form);
      localStorage.setItem("token", res.data.token);
      setUser(res.data.user);
      setView("dashboard");
      fetchStores();
      alert("تم التسجيل");
    } catch (err) {
      alert(err.response?.data?.message || "خطأ");
    }
  };

  const handleLogin = async (form) => {
    try {
      const res = await API.post("/auth/login", form);
      localStorage.setItem("token", res.data.token);
      setUser(res.data.user);
      setView("dashboard");
      fetchStores();
      alert("تم الدخول");
    } catch (err) {
      alert(err.response?.data?.message || "خطأ");
    }
  };

  const createStore = async (name, type) => {
    try {
      const res = await API.post("/stores", { name, type });
      alert(res.data.message);
      fetchMe();
      fetchStores();
    } catch (err) {
      alert(err.response?.data?.message || "خطأ");
    }
  };

  const requestPayment = async (storeId, amount, method) => {
    try {
      const res = await API.post("/payments/request", { storeId, amount, method });
      return res.data;
    } catch (err) {
      alert(err.response?.data?.message || "خطأ");
    }
  };

  const uploadReceipt = async (paymentId, file) => {
    const form = new FormData();
    form.append("receipt", file);
    try {
      const res = await API.post(`/payments/upload/${paymentId}`, form, {
        headers: { "Content-Type": "multipart/form-data" }
      });
      alert("تم رفع الإيصال");
      fetchMe();
    } catch (err) {
      alert(err.response?.data?.message || "خطأ");
    }
  };

  return (
    <div className="p-6">
      <header className="flex justify-between items-center mb-6">
        <h1 className="text-xl font-bold">سوق الفلاح</h1>
        <nav className="space-x-3">
          <button onClick={() => setView("home")}>الرئيسية</button>
          <button onClick={() => setView("stores")}>المتاجر</button>
          {user ? (
            <>
              <button onClick={() => setView("dashboard")}>لوحة التحكم</button>
              <button onClick={() => { localStorage.removeItem("token"); setUser(null); setView('home'); }}>خروج</button>
            </>
          ) : (
            <>
              <button onClick={() => setView("register")}>تسجيل</button>
              <button onClick={() => setView("login")}>دخول</button>
            </>
          )}
        </nav>
      </header>

      <main>
        {view === "home" && (
          <div>
            <h2 className="text-lg font-semibold mb-2">مرحبا بك في سوق الفلاح</h2>
            <p>منصة لربط الفلاحين، تجّار الجملة، التجزئة وناقلين البضائع.</p>
          </div>
        )}

        {view === "register" && <RegisterForm onSubmit={handleRegister} />}
        {view === "login" && <LoginForm onSubmit={handleLogin} />}

        {view === "stores" && (
          <div>
            <h3 className="font-bold mb-2">المتاجر</h3>
            <ul>
              {stores.map(s => (
                <li key={s.id || s._id} className="border p-2 mb-2 flex justify-between items-center">
                  <div>
                    <strong>{s.name}</strong> — <span className="text-gray-600">{s.type}</span>
                    <div className="text-sm text-gray-500">{s.location || ''} — {s.products || ''}</div>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        )}

        {view === "dashboard" && user && (
          <Dashboard
            user={user}
            stores={stores}
            onCreateStore={createStore}
            onRequestPayment={requestPayment}
            onUploadReceipt={uploadReceipt}
            notifications={notifications}
          />
        )}
      </main>
    </div>
  );
}

function RegisterForm({ onSubmit }) {
  const [form, setForm] = useState({ fullName: "", email: "", phone: "", password: "" });
  return (
    <form onSubmit={(e) => { e.preventDefault(); onSubmit(form); }} className="space-y-2">
      <input required placeholder="الاسم" value={form.fullName} onChange={e => setForm({...form, fullName: e.target.value})} className="border p-2 w-full" />
      <input required type="email" placeholder="الإيميل" value={form.email} onChange={e => setForm({...form, email: e.target.value})} className="border p-2 w-full" />
      <input required placeholder="الهاتف" value={form.phone} onChange={e => setForm({...form, phone: e.target.value})} className="border p-2 w-full" />
      <input required type="password" placeholder="كلمة المرور" value={form.password} onChange={e => setForm({...form, password: e.target.value})} className="border p-2 w-full" />
      <button className="px-4 py-2 bg-green-600 text-white rounded">تسجيل</button>
    </form>
  );
}

function LoginForm({ onSubmit }) {
  const [form, setForm] = useState({ email: "", password: ""});
  return (
    <form onSubmit={(e) => { e.preventDefault(); onSubmit(form); }} className="space-y-2">
      <input required type="email" placeholder="الإيميل" value={form.email} onChange={e => setForm({...form, email: e.target.value})} className="border p-2 w-full" />
      <input required type="password" placeholder="كلمة المرور" value={form.password} onChange={e => setForm({...form, password: e.target.value})} className="border p-2 w-full" />
      <button className="px-4 py-2 bg-blue-600 text-white rounded">دخول</button>
    </form>
  );
}

function Dashboard({ user, stores, onCreateStore, onRequestPayment, onUploadReceipt, notifications }) {
  const [storeName, setStoreName] = useState("");
  const [storeType, setStoreType] = useState("فلاح");
  const [paymentInfo, setPaymentInfo] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);

  const handleCreate = async () => {
    if (!storeName) return alert("أدخل اسم المتجر");
    await onCreateStore(storeName, storeType);
    setStoreName("");
  };

  const handleRequestPayment = async (storeId) => {
    const res = await onRequestPayment(storeId, 6500, "bpaid");
    setPaymentInfo(res);
  };

  const handleUpload = async (paymentId) => {
    if (!selectedFile) return alert("اختر ملف");
    await onUploadReceipt(paymentId, selectedFile);
    setPaymentInfo(null);
  };

  return (
    <div>
      <h3 className="font-bold">لوحة التحكم</h3>
      <p>مرحباً {user.fullName}</p>

      <div className="mt-4 border p-3">
        <h4 className="font-semibold">إنشاء متجر جديد</h4>
        <input placeholder="اسم المتجر" value={storeName} onChange={e => setStoreName(e.target.value)} className="border p-2 w-full mb-2"/>
        <select value={storeType} onChange={e => setStoreType(e.target.value)} className="border p-2 w-full mb-2">
          <option value="فلاح">فلاح</option>
          <option value="جملة">تاجر جملة</option>
          <option value="تجزئة">تاجر تجزئة</option>
          <option value="نقل">نقل</option>
        </select>
        <button onClick={handleCreate} className="px-3 py-1 bg-green-600 text-white rounded">أنشئ المتجر</button>
      </div>

      <div className="mt-4">
        <h4 className="font-semibold">متاجرك</h4>
        <ul>
          {stores.filter(s => s.owner && s.owner.id === user.id).map(s => (
            <li key={s.id || s._id} className="border p-2 mb-2">
              <strong>{s.name}</strong> — الحالة: {s.status}
              <div>ينتهي في: {s.end_date}</div>
              {s.status === 'expired' && (
                <div>
                  <p className="text-red-600 font-bold">انتهت مدة الاشتراك. لا تستطيع الدخول. الرجاء تجديد الاشتراك.</p>
                  <button onClick={() => handleRequestPayment(s.id)} className="px-3 py-1 bg-yellow-500 rounded mt-2">اطلب الدفع (بريدي موب)</button>
                </div>
              )}
            </li>
          ))}
        </ul>
      </div>

      {paymentInfo && (
        <div className="mt-4 p-3 bg-yellow-50">
          <h4>تعليمات الدفع</h4>
          <p>مرجع الدفع: <code>{paymentInfo.paymentRequest.payment_ref}</code></p>
          <p>{paymentInfo.instructions && paymentInfo.instructions.note}</p>
          <input type="file" onChange={e => setSelectedFile(e.target.files[0])} />
          <button onClick={() => handleUpload(paymentInfo.paymentRequest.id)} className="px-3 py-1 bg-green-600 rounded mt-2">ارفق الإيصال</button>
        </div>
      )}

      <div className="mt-4">
        <h4 className="font-semibold">الإشعارات</h4>
        <ul>
          {notifications.map(n => <li key={n.id} className="border p-2 mb-1">{n.message}</li>)}
        </ul>
      </div>

    </div>
  );
}

export default App;
