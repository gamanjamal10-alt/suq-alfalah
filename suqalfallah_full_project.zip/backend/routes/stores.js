const express = require("express");
const { Store, Subscription, Notification } = require("../models");
const { authMiddleware } = require("../middleware/auth");
const router = express.Router();

const addDays = (date, days) => {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d;
};
const addYears = (date, years) => {
  const d = new Date(date);
  d.setFullYear(d.getFullYear() + years);
  return d;
};

router.get("/", async (req, res) => {
  try {
    const stores = await Store.findAll({ include: ["owner"] });
    res.json(stores);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "خطأ في السيرفر" });
  }
});

router.post("/", authMiddleware, async (req, res) => {
  try {
    const { name, type } = req.body;
    const owner_id = req.user.id;

    const startDate = new Date();
    const endDate = addDays(startDate, 30);
    const store = await Store.create({
      name, type, owner_id,
      start_date: startDate,
      end_date: endDate,
      status: "trial",
      subscription_type: "trial"
    });

    await Notification.create({
      user_id: owner_id,
      message: `تم إنشاء متجرك "${name}". لديك 30 يوماً تجربة مجانية (ينتهي بتاريخ ${endDate.toLocaleDateString()}).`
    });

    res.status(201).json({ message: "متجر أنشئ مع تجربة مجانية 30 يوم", store });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "خطأ في السيرفر" });
  }
});

router.post("/renew/:storeId", authMiddleware, async (req, res) => {
  try {
    const { storeId } = req.params;
    const { amount = 6500, payment_method = "manual" } = req.body;

    const store = await Store.findByPk(storeId);
    if (!store) return res.status(404).json({ message: "المتجر غير موجود" });

    if (store.owner_id !== req.user.id && !req.user.is_admin) {
      return res.status(403).json({ message: "ليس لديك صلاحية لتجديد هذا المتجر" });
    }

    const now = new Date();
    const startDate = now;
    const endDate = addYears(now, 1);

    const subscription = await Subscription.create({
      store_id: store.id,
      amount,
      payment_method,
      start_date: startDate,
      end_date: endDate
    });

    store.start_date = startDate;
    store.end_date = endDate;
    store.status = "active";
    store.subscription_type = "yearly";
    store.last_notification = null;
    await store.save();

    await Notification.create({
      user_id: store.owner_id,
      message: `تم تجديد اشتراك متجر "${store.name}" لمدة سنة (ينتهي بتاريخ ${endDate.toLocaleDateString()}).`
    });

    res.json({ message: "تم تجديد الاشتراك لمدة سنة", store, subscription });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "خطأ في السيرفر" });
  }
});

module.exports = router;
