const express = require("express");
const { User, Store, Notification } = require("../models");
const { authMiddleware } = require("../middleware/auth");
const router = express.Router();

router.get("/me", authMiddleware, async (req, res) => {
  try {
    const user = await User.findByPk(req.user.id, {
      attributes: ["id","fullName","email","phone","is_admin"]
    });
    const stores = await Store.findAll({ where: { owner_id: user.id } });
    const notifications = await Notification.findAll({ where: { user_id: user.id }, order: [["created_at","DESC"]], limit: 50 });
    res.json({ user, stores, notifications });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "خطأ في السيرفر" });
  }
});

router.get("/notifications", authMiddleware, async (req, res) => {
  try {
    const notifications = await Notification.findAll({ where: { user_id: req.user.id }, order: [["created_at","DESC"]] });
    res.json(notifications);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "خطأ في السيرفر" });
  }
});

module.exports = router;
