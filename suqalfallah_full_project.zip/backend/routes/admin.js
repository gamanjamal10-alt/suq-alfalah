const express = require("express");
const { User, Store } = require("../models");
const { authMiddleware, adminOnly } = require("../middleware/auth");
const router = express.Router();

router.get("/users", authMiddleware, adminOnly, async (req, res) => {
  const users = await User.findAll({ attributes: ["id","fullName","email","phone","is_admin"] });
  res.json(users);
});

router.get("/stores", authMiddleware, adminOnly, async (req, res) => {
  const stores = await Store.findAll({ include: ["owner"] });
  res.json(stores);
});

router.post("/stores/:id/toggle", authMiddleware, adminOnly, async (req, res) => {
  const store = await Store.findByPk(req.params.id);
  if (!store) return res.status(404).json({ message: "المتجر غير موجود" });
  store.status = store.status === "active" ? "expired" : "active";
  await store.save();
  res.json({ message: "تم تغيير حالة المتجر", store });
});

module.exports = router;
