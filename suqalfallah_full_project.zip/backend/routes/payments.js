const express = require("express");
const { PaymentRequest, Store, Notification, Subscription } = require("../models");
const { authMiddleware, adminOnly } = require("../middleware/auth");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const router = express.Router();

const uploadDir = path.join(__dirname, "..", "uploads", "receipts");
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `${Date.now()}-${Math.round(Math.random()*1e6)}${ext}`);
  }
});
const upload = multer({ storage });

const genPaymentRef = (storeName) => {
  const short = (storeName || "STORE").toString().replace(/\s+/g, "-").slice(0,12);
  return `${short}-${Date.now().toString().slice(-6)}`;
};

router.post("/request", authMiddleware, async (req, res) => {
  try {
    const { storeId, amount, method } = req.body;
    if (!storeId || !amount || !method) return res.status(400).json({ message: "الحقول ناقصة" });

    const store = await Store.findByPk(storeId);
    if (!store) return res.status(404).json({ message: "المتجر غير موجود" });
    if (store.owner_id !== req.user.id && !req.user.is_admin) {
      return res.status(403).json({ message: "ليس لديك صلاحية" });
    }

    const payment_ref = genPaymentRef(store.name);
    const pr = await PaymentRequest.create({
      store_id: storeId,
      user_id: req.user.id,
      amount,
      method,
      payment_ref,
      status: "pending"
    });

    await Notification.create({
      user_id: req.user.id,
      message: `تم إنشاء طلب دفع لمرجع ${payment_ref}. اتبع تعليمات الدفع وارفق الإيصال.`
    });

    const instructions = {
      bpaid: {
        label: "بريدي موب",
        phone: "0799123456",
        note: `أدخل المرجع Payment Ref: ${payment_ref} في خانة التحويل وأرسل الإيصال.`
      },
      ccp: {
        label: "CCP (بريد الجزائر)",
        account: "1234567890",
        note: `أدخل المرجع Payment Ref: ${payment_ref} في وصف التحويل وأرسل الإيصال.`
      }
    };

    res.status(201).json({ message: "تم إنشاء طلب الدفع", paymentRequest: pr, instructions: instructions[method] });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "خطأ في السيرفر" });
  }
});

router.post("/upload/:paymentId", authMiddleware, upload.single("receipt"), async (req, res) => {
  try {
    const { paymentId } = req.params;
    const pr = await PaymentRequest.findByPk(paymentId);
    if (!pr) return res.status(404).json({ message: "طلب الدفع غير موجود" });
    if (pr.user_id !== req.user.id && !req.user.is_admin) return res.status(403).json({ message: "ليس لديك صلاحية" });

    if (!req.file) return res.status(400).json({ message: "أرفق صورة الإيصال" });
    pr.receipt_url = `/uploads/receipts/${req.file.filename}`;
    pr.status = "pending";
    await pr.save();

    await Notification.create({
      user_id: req.user.id,
      message: `تم رفع إيصال لطلب الدفع ${pr.payment_ref}. سيقوم المدير بالتحقق.`
    });

    res.json({ message: "تم رفع الإيصال بنجاح", paymentRequest: pr });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "خطأ في السيرفر" });
  }
});

router.get("/me", authMiddleware, async (req, res) => {
  try {
    const list = await PaymentRequest.findAll({ where: { user_id: req.user.id }, order: [["created_at","DESC"]] });
    res.json(list);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "خطأ في السيرفر" });
  }
});

router.get("/admin/list", authMiddleware, adminOnly, async (req, res) => {
  try {
    const list = await PaymentRequest.findAll({ include: ["user","store"], order: [["created_at","DESC"]] });
    res.json(list);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "خطأ في السيرفر" });
  }
});

router.post("/admin/verify/:paymentId", authMiddleware, adminOnly, async (req, res) => {
  try {
    const { paymentId } = req.params;
    const pr = await PaymentRequest.findByPk(paymentId);
    if (!pr) return res.status(404).json({ message: "طلب الدفع غير موجود" });

    pr.status = "verified";
    await pr.save();

    const store = await Store.findByPk(pr.store_id);
    const now = new Date();
    const nextYear = new Date(now); nextYear.setFullYear(nextYear.getFullYear() + 1);

    store.start_date = now;
    store.end_date = nextYear;
    store.status = "active";
    store.subscription_type = "yearly";
    store.last_notification = null;
    await store.save();

    await Subscription.create({
      store_id: store.id,
      amount: pr.amount,
      payment_method: pr.method === "bpaid" ? "بريدي موب" : "CCP",
      start_date: now,
      end_date: nextYear
    });

    await Notification.create({
      user_id: pr.user_id,
      message: `✅ تم تأكيد الدفع لمرجع ${pr.payment_ref}. تم تفعيل متجرك لمدة سنة حتى ${nextYear.toLocaleDateString()}.`
    });

    res.json({ message: "تم توثيق الدفع وتفعيل المتجر", paymentRequest: pr, store });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "خطأ في السيرفر" });
  }
});

router.post("/admin/reject/:paymentId", authMiddleware, adminOnly, async (req, res) => {
  try {
    const pr = await PaymentRequest.findByPk(req.params.paymentId);
    if (!pr) return res.status(404).json({ message: "طلب الدفع غير موجود" });
    pr.status = "rejected";
    await pr.save();

    await Notification.create({
      user_id: pr.user_id,
      message: `⚠️ تم رفض إيصال الدفع لمرجع ${pr.payment_ref}. يرجى رفع إيصال صالح أو التواصل معنا.`
    });

    res.json({ message: "تم رفض الإيصال", paymentRequest: pr });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "خطأ في السيرفر" });
  }
});

module.exports = router;
