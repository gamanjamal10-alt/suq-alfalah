const express = require("express");
require("dotenv").config();
const cors = require("cors");
const path = require("path");

const { sequelize } = require("./models");

const authRoutes = require("./routes/auth");
const storeRoutes = require("./routes/stores");
const userRoutes = require("./routes/users");
const adminRoutes = require("./routes/admin");
const paymentsRoutes = require("./routes/payments");

const checkSubscriptionsTask = require("./cron/checkSubscriptions");

const app = express();
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.use("/api/auth", authRoutes);
app.use("/api/stores", storeRoutes);
app.use("/api/users", userRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/payments", paymentsRoutes);

const PORT = process.env.PORT || 5000;
(async () => {
  try {
    await sequelize.authenticate();
    await sequelize.sync();
    console.log("✅ DB connected & synced");

    checkSubscriptionsTask.start();
    console.log("✅ Cron job started");

    app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
  } catch (err) {
    console.error("❌ Error starting server:", err);
  }
})();
