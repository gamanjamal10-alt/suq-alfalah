const { DataTypes } = require("sequelize");

module.exports = (sequelize) => {
  return sequelize.define("Subscription", {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    amount: { type: DataTypes.DECIMAL(10,2), allowNull: false },
    payment_method: { type: DataTypes.STRING(100), allowNull: true },
    start_date: { type: DataTypes.DATEONLY, allowNull: false },
    end_date: { type: DataTypes.DATEONLY, allowNull: false },
    store_id: { type: DataTypes.INTEGER, allowNull: false }
  }, {
    tableName: "subscriptions"
  });
};
