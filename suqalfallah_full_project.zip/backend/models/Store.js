const { DataTypes } = require("sequelize");

module.exports = (sequelize) => {
  return sequelize.define("Store", {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    name: { type: DataTypes.STRING(200), allowNull: false },
    type: { type: DataTypes.STRING(50), allowNull: false },
    start_date: { type: DataTypes.DATEONLY, allowNull: false },
    end_date: { type: DataTypes.DATEONLY, allowNull: false },
    status: { type: DataTypes.ENUM("trial", "active", "expired"), defaultValue: "trial" },
    subscription_type: { type: DataTypes.ENUM("trial", "yearly"), defaultValue: "trial" },
    last_notification: { type: DataTypes.DATE, allowNull: true },
    owner_id: { type: DataTypes.INTEGER, allowNull: false }
  }, {
    tableName: "stores"
  });
};
