const { DataTypes } = require("sequelize");

module.exports = (sequelize) => {
  return sequelize.define("Notification", {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    message: { type: DataTypes.TEXT, allowNull: false },
    is_read: { type: DataTypes.BOOLEAN, defaultValue: false },
    user_id: { type: DataTypes.INTEGER, allowNull: false }
  }, {
    tableName: "notifications"
  });
};
