const { Sequelize } = require("sequelize");
require("dotenv").config();

const sequelize = new Sequelize(process.env.DB_NAME, process.env.DB_USER, process.env.DB_PASS, {
  host: process.env.DB_HOST,
  dialect: "mysql",
  logging: false,
  define: {
    underscored: true,
    timestamps: true
  }
});

const User = require("./User")(sequelize);
const Store = require("./Store")(sequelize);
const Subscription = require("./Subscription")(sequelize);
const Notification = require("./Notification")(sequelize);
const PaymentRequest = require("./PaymentRequest")(sequelize);

// Associations
User.hasMany(Store, { foreignKey: "owner_id", as: "stores" });
Store.belongsTo(User, { foreignKey: "owner_id", as: "owner" });

Store.hasMany(Subscription, { foreignKey: "store_id", as: "subscriptions" });
Subscription.belongsTo(Store, { foreignKey: "store_id", as: "store" });

User.hasMany(Notification, { foreignKey: "user_id", as: "notifications" });
Notification.belongsTo(User, { foreignKey: "user_id", as: "user" });

User.hasMany(PaymentRequest, { foreignKey: "user_id", as: "payments" });
PaymentRequest.belongsTo(User, { foreignKey: "user_id", as: "user" });
Store.hasMany(PaymentRequest, { foreignKey: "store_id", as: "payments" });
PaymentRequest.belongsTo(Store, { foreignKey: "store_id", as: "store" });

module.exports = {
  sequelize,
  User,
  Store,
  Subscription,
  Notification,
  PaymentRequest
};
