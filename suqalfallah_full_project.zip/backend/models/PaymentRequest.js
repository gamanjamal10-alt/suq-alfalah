const { DataTypes } = require("sequelize");

module.exports = (sequelize) => {
  return sequelize.define("PaymentRequest", {
    id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
    store_id: { type: DataTypes.INTEGER, allowNull: false },
    user_id: { type: DataTypes.INTEGER, allowNull: false },
    amount: { type: DataTypes.DECIMAL(10,2), allowNull: false },
    method: { type: DataTypes.ENUM("bpaid","ccp"), allowNull: false },
    payment_ref: { type: DataTypes.STRING(100), allowNull: false },
    status: { type: DataTypes.ENUM("pending","verified","rejected"), defaultValue: "pending" },
    receipt_url: { type: DataTypes.STRING(255), allowNull: true }
  }, {
    tableName: "payment_requests"
  });
};
